source/ADC.o source/ADC.d: ../source/ADC.c ../source/ADC.h \
 ../source/hardware.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/fsl_device_registers.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/MK64F12.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cm4.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cmInstr.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/cmsis_gcc.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cmFunc.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cmSimd.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/system_MK64F12.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/MK64F12_features.h \
 D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cm4.h
../source/ADC.h:
../source/hardware.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/fsl_device_registers.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/MK64F12.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cm4.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cmInstr.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/cmsis_gcc.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cmFunc.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cmSimd.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/system_MK64F12.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/MK64F12_features.h:
D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos\ Practicos\TP2\PingPong\ Buffer-20260406T221404Z-3-001\PingPong\ Buffer\CMSIS/core_cm4.h:
