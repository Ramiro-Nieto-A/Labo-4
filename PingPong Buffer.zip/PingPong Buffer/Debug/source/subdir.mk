################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../source/ADC.c \
../source/PingPongBuffer.c \
../source/hardware.c \
../source/main.c \
../source/ports.c 

C_DEPS += \
./source/ADC.d \
./source/PingPongBuffer.d \
./source/hardware.d \
./source/main.d \
./source/ports.d 

OBJS += \
./source/ADC.o \
./source/PingPongBuffer.o \
./source/hardware.o \
./source/main.o \
./source/ports.o 


# Each subdirectory must supply rules for building sources it contributes
source/%.o: ../source/%.c source/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: MCU C Compiler'
	arm-none-eabi-gcc -DCR_INTEGER_PRINTF -DSDK_DEBUGCONSOLE=0 -D__MCUXPRESSO -D__USE_CMSIS -DDEBUG -DCPU_MK64FN1M0VDC12 -DCPU_MK64FN1M0VDC12_cm4 -D__NEWLIB__ -I"D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos Practicos\TP2\PingPong Buffer-20260406T221404Z-3-001\PingPong Buffer\source" -I"D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos Practicos\TP2\PingPong Buffer-20260406T221404Z-3-001\PingPong Buffer" -I"D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos Practicos\TP2\PingPong Buffer-20260406T221404Z-3-001\PingPong Buffer\startup" -I"D:\Bruno\ITBA\Profesor\ASSD\1Q2026\Trabajos Practicos\TP2\PingPong Buffer-20260406T221404Z-3-001\PingPong Buffer\CMSIS" -O3 -fno-common -g3 -gdwarf-4 -Wall -c -fmessage-length=0 -fno-builtin -ffunction-sections -fdata-sections -Wa,-adhlns="$@.lst" -fmacro-prefix-map="$(<D)/"= -mcpu=cortex-m4 -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -D__NEWLIB__ -fstack-usage -specs=nano.specs -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.o)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-source

clean-source:
	-$(RM) ./source/ADC.d ./source/ADC.o ./source/PingPongBuffer.d ./source/PingPongBuffer.o ./source/hardware.d ./source/hardware.o ./source/main.d ./source/main.o ./source/ports.d ./source/ports.o

.PHONY: clean-source

