/*
 * main.c
 *
 *  Created on: Jun 23, 2025
 *      Author: mpaurabe
 */

#include "fsl_device_registers.h"
#include "hardware.h"
#include "PingPongBuffer.h"
#include <ports.h>
#include "config.h"

#define BUFFER_SIZE 1024
#define SAMPLE_RATE_HZ 200000U


volatile bool nextsample;

volatile uint16_t *adc_in;
volatile uint16_t *dac_out;
static int alternate = -1;

void my_app(void);

int main(void)
{
	hw_Init();
	Init_Ports();
	PingPongBuffer_Init(SAMPLE_RATE_HZ,BUFFER_SIZE);

    for(;;)
    {
        if(SW2_read())
        	alternate = -1;

        if(SW3_read())
        	alternate = 1;


    	if(nextsample == 1)
        {
        	my_app();
        	nextsample = 0;
        }
    }
}


void my_app(void)
{
	static float modul = 0.5;
	volatile uint16_t *adc_in = GetBufferIn();
	volatile uint16_t *dac_out = SetBufferOut();

	TurnON(TP0);

	dac_out[0]=4095;
	for (int i = 1; i < BUFFER_SIZE; i++)
		dac_out[i]= (modul*((int)adc_in[i]-2048))+2048;

	modul *=alternate;
	TurnOFF(TP0);

}

